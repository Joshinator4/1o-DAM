/*
 *Gestión de Clientes: alta, baja (solo si no tiene cuentas corrientes), modificación (todo salvo dni). 
 *Gestión de cuentas corrientes (alta de cuenta, baja de cuenta [no la elimina de la base de datos para no perder los datos], ingreso en cuenta,
 *salida de cuenta, transferencia [tiene una cuenta emisora y una receptora, generará dos movimientos].
 *Gestión de movimientos de la cuenta corriente de un cliente. Recibe el número de cuenta corriente a gestionar y permite: listar los movimientos entre fechas. 
*/
package cuentasCorrientes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		int opcionDeseada;
		Connection conexion = null;
		
		try {
			String url = "jdbc:mysql://localhost:3306/cuentas_corrientes";
			String user = "java";
			String pass = "1234";
			conexion = DriverManager.getConnection(url, user, pass);

		} catch (SQLException ex) {
			ex.printStackTrace();
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}

		do {
			System.out.println(
					"Elija un opcion:\n1.-Alta cliente.\n2.-Baja de un cliente(solo si no tiene cuentas asociadas)"
							+ "\n3.-Modificar datos de un cliente.\n4.-Alta de cuenta" + "\n5.-Dar de baja una cuenta\n"
							+ "6.-Ingreso\n7.-Retirada\n8.-Transeferencia\n9.-Gestionar movimientos por fecha\n0.-Salir del programa");
			opcionDeseada = teclado.nextInt();
			switch (opcionDeseada) {
			case (1): {

				altaCliente(teclado, conexion);
				break;

			}
			case (2): {

				bajaCliente(teclado, conexion);
				break;

			}
			case (3): {

				modificarCliente(teclado, conexion);
				break;

			}
			case (4): {
				altaCuenta(teclado, conexion);
				break;

			}
			case (5): {
				bajaCuenta(teclado, conexion);
				break;

			}
			case (6): {
				ingreso(teclado, conexion);
				break;

			}
			case (7): {
				retirada(teclado, conexion);
				break;

			}
			case (8): {
				transferencia(teclado, conexion);
				break;

			}
			case (9): {
				listarMovimientos(teclado, conexion);
				break;

			}
			case (0): {
				System.out.println("Se va a proceder a cerrar el programa, ¡Hasta Pronto!");
				try {
					conexion.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			}
			default: {
				System.out.println(
						"Se ha introducido una opcion incorrecta, introduzca un numero de cualquiera de las funciones");
			}

			}

		} while (opcionDeseada != 0);

	}

	public static void altaCliente(Scanner teclado, Connection conexion) {
		String dni, nombre, telefono, direccion;
		String consulta = "insert into clientes (dni, nombre, telefono, direccion) values(?,?,?,?)";
		teclado.nextLine();
		System.out.println("Introduzca el dni del cliente");
		dni = teclado.nextLine();
		System.out.println("Introduzca el nombre del cliente");
		nombre = teclado.nextLine();
		System.out.println("Introduzca el telefono del cliente");
		telefono = teclado.nextLine();
		System.out.println("Introduzca la direccion del cliente");
		direccion = teclado.nextLine();

		try {
			PreparedStatement sentenciaConsulta = conexion.prepareStatement(consulta);
			sentenciaConsulta.setString(1, dni);
			sentenciaConsulta.setString(2, nombre);
			sentenciaConsulta.setString(3, telefono);
			sentenciaConsulta.setString(4, direccion);

			sentenciaConsulta.executeUpdate();
			sentenciaConsulta.close();
		} catch (SQLException ex) {
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
			System.err.printf("Se ha producido un error al ejecutar la consulta SQL.");
		}

	}

	public static void bajaCliente(Scanner teclado, Connection conexion) {
		String dni;
		String consulta = "delete from clientes where dni = (?)";
		teclado.nextLine();
		System.out.println("Introduzca el dni del cliente a borrar");
		dni = teclado.nextLine();
		int cantidad = filtrarDni(teclado, conexion, dni);
		if (cantidad > 0) {
			try {
				PreparedStatement sentenciaConsulta = conexion.prepareStatement(consulta);
				sentenciaConsulta.setString(1, dni);

				sentenciaConsulta.executeUpdate();
				sentenciaConsulta.close();
			} catch (SQLException ex) {
				if (ex.getErrorCode() == 1451) {
					System.out.println("No se puede borrar a un cliente que tiene cuentas corrientes abiertas");
				} else {
					System.err.printf("Se ha producido un error al ejecutar la consulta SQL.");
				}

			}
		} else {
			System.out.println("El cliente con ese dni no existe");
		}
	}

	public static void modificarCliente(Scanner teclado, Connection conexion) {
		String dni, nombre, telefono, direccion;
		String consulta = "update clientes set nombre = (?), telefono = (?), direccion = (?) where dni = (?)";
		teclado.nextLine();
		System.out.println("Introduzca el dni del cliente");
		dni = teclado.nextLine();
		int cantidad = filtrarDni(teclado, conexion, dni);
		if (cantidad > 0) {
			System.out.println("Introduzca el nuevo nombre del cliente");
			nombre = teclado.nextLine();
			System.out.println("Introduzca el nuevo telefono del cliente");
			telefono = teclado.nextLine();
			System.out.println("Introduzca la nueva direccion del cliente");
			direccion = teclado.nextLine();

			try {
				PreparedStatement sentenciaConsulta = conexion.prepareStatement(consulta);
				sentenciaConsulta.setString(1, nombre);
				sentenciaConsulta.setString(2, telefono);
				sentenciaConsulta.setString(3, direccion);
				sentenciaConsulta.setString(4, dni);

				sentenciaConsulta.executeUpdate();
				sentenciaConsulta.close();

			} catch (SQLException ex) {
				System.out.println("SQLException: " + ex.getMessage());
				System.out.println("SQLState: " + ex.getSQLState());
				System.out.println("VendorError: " + ex.getErrorCode());
				System.err.printf("Se ha producido un error al ejecutar la consulta SQL.");

			}
		} else {
			System.out.println("El cliente con ese dni no existe");
		}

	}

	public static void altaCuenta(Scanner teclado, Connection conexion) {
		String dniCliente, situacion = "activa";
		double saldo;
		String consulta = "insert into cuentas (dni_cliente, situacion, saldo) values(?,?,?)";
		teclado.nextLine();
		System.out.println("Introduzca el dni del cliente");
		dniCliente = teclado.nextLine();
		int cantidad = filtrarDni(teclado, conexion, dniCliente);
		if (cantidad > 0) {
			System.out.println("Introduzca el saldo inicial de la cuenta");
			saldo = teclado.nextDouble();

			try {
				PreparedStatement sentenciaConsulta = conexion.prepareStatement(consulta);
				sentenciaConsulta.setString(1, dniCliente);
				sentenciaConsulta.setString(2, situacion);
				sentenciaConsulta.setDouble(3, saldo);

				sentenciaConsulta.executeUpdate();
				sentenciaConsulta.close();

			} catch (SQLException ex) {
				System.out.println("SQLException: " + ex.getMessage());
				System.out.println("SQLState: " + ex.getSQLState());
				System.out.println("VendorError: " + ex.getErrorCode());
				System.err.printf("Se ha producido un error al ejecutar la consulta SQL.");

			}
		} else {
			System.out.println("El cliente con ese dni no existe");
		}

	}

	public static void bajaCuenta(Scanner teclado, Connection conexion) {
		String situacion = "baja";
		int numeroCuenta;
		String consulta = "update cuentas set situacion = (?) where numero_cuenta = (?)";
		int cantidad = filtrarDni(teclado, conexion);
		if (cantidad > 0) {
			System.out.println("Introduzca el numero de cuenta");
			numeroCuenta = teclado.nextInt();
			try {

				PreparedStatement sentenciaConsulta = conexion.prepareStatement(consulta);
				sentenciaConsulta.setString(1, situacion);
				sentenciaConsulta.setInt(2, numeroCuenta);

				sentenciaConsulta.executeUpdate();
				sentenciaConsulta.close();

			} catch (SQLException ex) {
				System.out.println("SQLException: " + ex.getMessage());
				System.out.println("SQLState: " + ex.getSQLState());
				System.out.println("VendorError: " + ex.getErrorCode());
				System.err.printf("Se ha producido un error al ejecutar la consulta SQL.");

			}
		} else {
			System.out.println("El cliente con ese dni no existe");
		}

	}

	public static int filtrarDni(Scanner teclado, Connection conexion) {
		int devolucion = 0;
		String dniCliente;
		teclado.nextLine();
		System.out.println("Introduzca el dni del cliente");
		dniCliente = teclado.nextLine();
		String consulta2 = "SELECT count(*) FROM clientes where dni = ?";
		try {
			PreparedStatement sentenciaConsulta2 = conexion.prepareStatement(consulta2);
			sentenciaConsulta2.setString(1, dniCliente);
			ResultSet resultado = sentenciaConsulta2.executeQuery();
			resultado.next();
			devolucion = resultado.getInt(1);
			sentenciaConsulta2.close();
			resultado.close();
		} catch (SQLException ex) {
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
			System.err.printf("Se ha producido un error al ejecutar la consulta SQL.");

		}

		return devolucion;

	}
	//metodo sobrecargado
	public static int filtrarDni(Scanner teclado, Connection conexion, String dni) {
		int devolucion = 0;
		String consulta2 = "SELECT count(*) FROM clientes where dni = ?";
		PreparedStatement sentenciaConsulta2;
		try {
			sentenciaConsulta2 = conexion.prepareStatement(consulta2);
			sentenciaConsulta2.setString(1, dni);
			ResultSet resultado = sentenciaConsulta2.executeQuery();
			resultado.next();
			devolucion = resultado.getInt(1);
			sentenciaConsulta2.close();
			resultado.close();
		} catch (SQLException ex) {
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
			System.err.printf("Se ha producido un error al ejecutar la consulta SQL.");

		}

		return devolucion;

	}
	

	public static void ingreso(Scanner teclado, Connection conexion) {
		int numeroCuenta;
		double ingreso, total;
		System.out.println("Introduzca el numero de cuenta");
		numeroCuenta = teclado.nextInt();
		System.out.println("Introduzca el saldo a ingresar");
		ingreso = teclado.nextDouble();
		total = consultaSaldo(numeroCuenta, conexion) + ingreso;
		actualizarSaldo(conexion, total, numeroCuenta);
		generarMovimientos(numeroCuenta, ingreso, generarFecha(), "ingreso", 0, "ingreso de dinero", conexion);

	}

	public static void retirada(Scanner teclado, Connection conexion) {
		int numeroCuenta;
		double retirada, total;
		System.out.println("Introduzca el numero de cuenta");
		numeroCuenta = teclado.nextInt();
		System.out.println("Introduzca el saldo a retirar");
		retirada = teclado.nextDouble();
		total = consultaSaldo(numeroCuenta, conexion) - retirada;
		actualizarSaldo(conexion, total, numeroCuenta);
		generarMovimientos(numeroCuenta, retirada, generarFecha(), "retirada", 0, "retirada de dinero", conexion);

	}

	public static double consultaSaldo(int numeroCuenta, Connection conexion) {
		double devolucion = 0;
		try {
			String consulta2 = "select saldo from cuentas where numero_cuenta = (?)";
			PreparedStatement sentenciaConsulta2 = conexion.prepareStatement(consulta2);
			sentenciaConsulta2.setInt(1, numeroCuenta);
			ResultSet resultado = sentenciaConsulta2.executeQuery();
			resultado.next();
			devolucion = resultado.getDouble(1);
			sentenciaConsulta2.close();
			resultado.close();
		} catch (SQLException ex) {
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
			System.err.printf("Se ha producido un error al ejecutar la consulta SQL.");
		}
		return devolucion;

	}

	public static void actualizarSaldo(Connection conexion, double total, int numeroCuenta) {
		String consulta = "update cuentas set saldo = (?) where numero_cuenta = (?)";
		try {
			PreparedStatement sentenciaConsulta = conexion.prepareStatement(consulta);
			sentenciaConsulta.setDouble(1, total);
			sentenciaConsulta.setInt(2, numeroCuenta);
			sentenciaConsulta.executeUpdate();
			sentenciaConsulta.close();

		} catch (SQLException ex) {
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
			System.err.printf("Se ha producido un error al ejecutar la consulta SQL.");

		}
	}
	
	public static Timestamp generarFecha() {
		LocalDateTime ahora = LocalDateTime.now();
		Timestamp fecha = Timestamp.valueOf(ahora);
		return fecha;
	}
	
	public static void transferencia(Scanner teclado, Connection conexion) {
		int numeroCuentaManda, numeroCuentaRecibe;
		double cantidadTransefe, saldoCuentaManda, saldoCuentaRecibe, saldoCuentaMandaFinal = 0, saldoCuentaRecibeFinal = 0;
		String concepto;
		System.out.println("Introduzca la cuenta que realiza la transferencia");
		numeroCuentaManda = teclado.nextInt();
		System.out.println("Introduzca la cuenta que recibe la transferencia");
		numeroCuentaRecibe = teclado.nextInt();
		System.out.println("Introduzca la cantidad a enviar");
		cantidadTransefe = teclado.nextDouble();
		teclado.nextLine();
		System.out.println("Añada un concepto");
		concepto = teclado.nextLine();
		
		saldoCuentaManda = consultaSaldo(numeroCuentaManda, conexion);
		saldoCuentaRecibe = consultaSaldo(numeroCuentaRecibe, conexion);
		saldoCuentaMandaFinal = saldoCuentaManda - cantidadTransefe;
		saldoCuentaRecibeFinal = saldoCuentaRecibe + cantidadTransefe;
		actualizarSaldo(conexion, saldoCuentaMandaFinal, numeroCuentaManda);
		actualizarSaldo(conexion, saldoCuentaRecibeFinal, numeroCuentaRecibe);
		generarMovimientos(numeroCuentaManda, cantidadTransefe, generarFecha(), "transferencia enviada", numeroCuentaRecibe, concepto, conexion);
		generarMovimientos(numeroCuentaRecibe, cantidadTransefe, generarFecha(), "transferencia recibida", numeroCuentaManda, concepto, conexion);
				
	}
	
	public static void generarMovimientos(int numCuenta,double importe, Timestamp fecha, String tipo, int numCuentaRecibe, String concepto, Connection conexion) {
		String consulta = "insert into movimientos values (?,?,?,?,?,?)";
		try {
			PreparedStatement sentenciaConsulta = conexion.prepareStatement(consulta);
			sentenciaConsulta.setInt(1, numCuenta);
			sentenciaConsulta.setDouble(2, importe);
			sentenciaConsulta.setTimestamp(3, fecha);
			sentenciaConsulta.setString(4, tipo);
			sentenciaConsulta.setInt(5, numCuentaRecibe);
			sentenciaConsulta.setString(6, concepto);

			sentenciaConsulta.executeUpdate();
			sentenciaConsulta.close();
		} catch (SQLException ex) {
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
			System.err.printf("Se ha producido un error al ejecutar la consulta SQL.");
		}
		
	}
	
	public static Timestamp pedirFecha(Scanner teclado, String orden) {
		Timestamp devolucion;
		int  dia1, mes1, anho1;
		System.out.println("Introduzca el dia de la " +  orden + " fecha");
		dia1 = teclado.nextInt();
		System.out.println("Introduzca el mes de la " +  orden + " fecha");
		mes1 = teclado.nextInt();
		System.out.println("Introduzca el año de la " +  orden + " fecha");
		anho1 = teclado.nextInt();
		LocalDateTime tiempo1 = LocalDateTime.of(anho1, mes1, dia1, 00, 00, 00, 00);
		devolucion = Timestamp.valueOf(tiempo1);
		return devolucion;
		
	}
	
	public static void listarMovimientos(Scanner teclado, Connection conexion) {
		int numCuenta;
		String consulta = "select * from cuentas_corrientes.movimientos where numero_cuenta = (?) and fecha_hora between (?) and (?)";
		System.out.println("Introduzca el numero de cuenta a consultar");
		numCuenta = teclado.nextInt();
		
		Timestamp fecha1 = pedirFecha(teclado, "primera");
		Timestamp fecha2 = pedirFecha(teclado, "segunda");
		try {
		PreparedStatement sentenciaConsulta2 = conexion.prepareStatement(consulta);
		sentenciaConsulta2.setTimestamp(1, fecha1);
		sentenciaConsulta2.setTimestamp(2, fecha2);
		sentenciaConsulta2.setInt(3, numCuenta);
		ResultSet resultado = sentenciaConsulta2.executeQuery();
		while(resultado.next()) {
			System.out.println("hola");
			System.out.println("numero_cuenta: " + resultado.getInt(1) + " importe: " + resultado.getDouble(2) + " fecha_hora: " + resultado.getTimestamp(3) + " tipo: " 
					+ resultado.getString(4) + " cuenta_transferida: " + resultado.getInt(5) + " concepto: " + resultado.getString(6));
		}
		sentenciaConsulta2.close();
		resultado.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
